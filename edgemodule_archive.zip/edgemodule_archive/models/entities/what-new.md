{"author": {"type": "string"},
"ms.service": {"type": "string", "allowed": ["azure-stack"]},
"ms.date": {"type": "string"},
"ms.lastreviewed": {"type": "string"},
"ms.topic": {"type": "string", "allowed": ["include"]},
"ms.author": {"type": "string"},
"ms.reviewer": {"type": "string"},
"ms.issue-id": {"type": "string"},
"ms.sub-service": {"type": "string", "allowed" : ["Advisory", "Alerts, Health Monitoring and Hardware", "App Services", "Backup and Disaster Recovery", "Billing or Usage Tracking", "Cloud Operator Issues", "Deployment", "Registration of Azure Stack", "Development Kit ASDK", "Marketplace Mgmt.", "Network", "Patch and Update", "Plans, Offers, Quota, or Subscriptions", "Security, Certificate and Secret Management, Support, Monitoring", "SQL MySQL", "Storage", "Tools and SDK", "Virtual Machines", "PowerShell, Developer Tools, SDKs", "Validation as a Service", "Release Notes (What's New/Known Issues)", "Kubernetes", "Add on RPs", "Solutions for Azure Stack Hub", "Developer using Azure Stack Hub", "Rugged Devices"] },
"title": {"type": "string"},
"Applicable": {"type": "string"},
"Description": {"type": "string"},
"For more information": {"type": "string"}
}