---
author: mattbriggs
ms.service: azure-stack
ms.topic: include
ms.date: 2020-08-14
ms.author: mabrigg
ms.reviewer: kivenkat
ms.lastreviewed: 2020-08-14
ms.sub-service: Virtual Machines
azs.tracking: 123456
azs.issue-id: known-issue-8bbc45b7-ebb0-ea11-a812-000d3a5465d8
azs.status: active
azs.topic-schema: known-issue
azs.audience: Operator
azs.highlight: False
---
### Storage account options

- Applicable to: all
- Description: In the user portal, the name of storage accounts is shown as Storage account - blob, file, table, queue ; however, file is not supported in Azure Stack Hub. 
- Remediation: NA
- Occurrence: Common