---
author: mattbriggs
ms.service: azure-stack
ms.topic: include
ms.date: 2020-08-14
ms.author: mabrigg
ms.reviewer: kivenkat
ms.lastreviewed: 2020-08-14
ms.sub-service: Virtual Machines
azs.tracking: 123456
azs.issue-id: known-issue-92bc45b7-ebb0-ea11-a812-000d3a5465d8
azs.status: active
azs.topic-schema: known-issue
azs.audience: Operator
azs.highlight: False
---
### Storage account settings

- Applicable to: all
- Description: In the user portal, the storage account Configuration blade shows an option to change security transfer type . The feature is currently not supported in Azure Stack Hub. 
- Remediation: NA
- Occurrence: Common