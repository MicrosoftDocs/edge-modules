---
author: mattbriggs
ms.service: azure-stack
ms.topic: include
ms.date: 2020-08-14
ms.author: mabrigg
ms.reviewer: kivenkat
ms.lastreviewed: 2020-08-14
ms.sub-service: Virtual Machines
azs.tracking: 123456
azs.issue-id: known-issue-9abc45b7-ebb0-ea11-a812-000d3a5465d8
azs.status: active
azs.topic-schema: known-issue
azs.audience: Operator
azs.highlight: False
---
### Storage account configuration

- Applicable to: all
- Description: In the user portal, when you create a storage account and view its Configuration , you cannot save configuration changes, as it results in an AJAX error. 
- Remediation: NA
- Occurrence: Common