---
author: mattbriggs
ms.service: azure-stack
ms.topic: include
ms.date: 2020-08-14
ms.author: mabrigg
ms.reviewer: kivenkat
ms.lastreviewed: 2020-08-14
ms.sub-service: Virtual Machines
azs.tracking: 123456
azs.issue-id: known-issue-ff0a8111-eab0-ea11-a812-000d3a5465d8
azs.status: active
azs.topic-schema: known-issue
azs.audience: Operator
azs.highlight: False
---
### Virtual machine diagnostic settings blade

- Applicable to: 1906-1907
- Description: The virtual machine diagnostic settings blade has a Sink tab, which asks for an Application Insight Account . This is the result of a new blade and is not yet supported in Azure Stack Hub.
- Remediation: None.
- Occurrence: Common